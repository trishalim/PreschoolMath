<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/form.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<script src="js/jquery.validate.js" ></script>
	<script src="js/account.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>
	<?php 
		include 'header.php'; 
		include 'dbconnect.php';
		$account = mysqli_query($conn,"select * from user where username='".$_SESSION['user']."'");
		if($account){
			$row =mysqli_fetch_assoc($account);
			
		}
		else echo "error";
		
	?>
	<body>
	<title>Preschool Math | Enrolled Students</title>
	<body>
	<div class="container">
		<h4>Account Settings</h4>
		<form class="form-horizontal" id="edit_acct" action="scripts/edit_account.php" method="post">
		  <div class="form-group">
			<label for="username" class="col-sm-2 control-label">Username</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="egusername" id="egusername" value="<?php echo $row['username'];?>" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group">
			<label for="f_name" class="col-sm-2 control-label">First Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="egf_name" id="egf_name" value="<?php echo $row['f_name'];?>" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group">
			<label for="l_name" class="col-sm-2 control-label">Last Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="egl_name" id="egl_name" value="<?php echo $row['l_name'];?>" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group pw">
			<label for="password" id="pwLabel" class="col-sm-2 control-label">Password</label>
			<div class="col-sm-10" style="padding-top:7px">
			   <a href="change_password.php?username=<?php echo $row['username'];?>" >Change password</a>
			</div>
		  </div>
		  <div class="modal-footer">
		  	<a href="account.php" id="cancel" type="button" class="btn btn-default edit" style="display:none;">Cancel</a>
			<button id="editGuardianBtn" type="button" class="btn btn-primary">Edit</button>
			<button id="saveGuardianBtn" class="btn btn-primary">Save changes</button>
		  </div>
		</form>
		
	</div>
	</body>
	</body>
</html>