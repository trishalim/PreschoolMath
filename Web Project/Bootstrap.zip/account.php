<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<script src="js/account.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>
	<?php 
		include 'header.php'; 
		include 'dbconnect.php';
		$account = mysqli_query($conn,"select * from user where username='".$_SESSION['user']."'");
		if($account){
			$row =mysqli_fetch_assoc($account);
			
		}
		else echo "error";
		
	?>
	<body>
	<title>Preschool Math | Enrolled Students</title>
	<body>
	<div class="container">
		<h3>Account Settings</h3>
		<form class="form-horizontal">
		  <div class="form-group">
			<label for="username" class="col-sm-2 control-label">Username</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="egusername" id="egusername" value="<?php echo $row['username'];?>" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group">
			<label for="f_name" class="col-sm-2 control-label">First Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="egf_name" id="egf_name" value="<?php echo $row['f_name'];?>" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group">
			<label for="l_name" class="col-sm-2 control-label">Last Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="egl_name" id="egl_name" value="<?php echo $row['l_name'];?>" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group">
			<label for="password" id="pwLabel" class="col-sm-2 control-label">Password</label>
			<div class="col-sm-10">
			  <a href="#" id="changePw" >Change password</a>
			  <input type="password" class="form-control" name="egpassword" id="egpassword" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group" id="egpasswordfield">
			<label for="cpassword" class="col-sm-2 control-label">New Password</label>
			<div class="col-sm-10">
			  <input type="password" class="form-control" name="egcpassword" id="egcpassword" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
			  <button id="editGuardianBtn" type="button" class="btn btn-default">Edit</button>
			  <button id="saveGuardianBtn" class="btn btn-default">Save changes</button>
			</div>
		  </div>
		</form>
		
	</div>
	</body>
	</body>
</html>