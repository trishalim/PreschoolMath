<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/form.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<script src="js/jquery.validate.js" ></script>
	<script src="js/change_password.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>
	<?php include 'header.php'; ?>
	<body>
	<title>Preschool Math | Enrolled Students</title>
	<body>
	
	<?php
		include 'dbconnect.php';
		$username = $_GET['username'];
	
	?>
	<span id="edit_user" hidden><?php echo $username;?></span>
	<div class="container">
		<h4>Change Password</h4>
		<form class="form-horizontal" method="post" id="change_password" action="scripts/change_password.php?username=<?php echo $username ?>">
		  <div class="form-group changepw">
			<label for="password" class="col-sm-3 control-label">Current Password</label>
			<div class="col-sm-9">
			  <input type="password" class="form-control" name="password" id="password" required="true">
			</div>
		  </div>
		  <div class="form-group changepw">
			<label for="password" class="col-sm-3 control-label">New Password</label>
			<div class="col-sm-9">
			  <input type="password" class="form-control" name="password1" id="password1" required="true">
			</div>
		  </div>
		  <div class="form-group changepw">
			<label for="password" class="col-sm-3 control-label">Confirm Password</label>
			<div class="col-sm-9">
			  <input type="password" class="form-control" name="password2" id="cnpassword2" required="true">
			</div>
		  </div>
		   <div class="modal-footer">
			<button type="button" onClick="history.go(-1);return true;" class="btn btn-default edit">Cancel</button>
			<button type="submit" class="btn btn-primary view">Change Password</button>
		  </div>
	</div>
	</body>
</html>