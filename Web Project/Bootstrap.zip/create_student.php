<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>
	<?php include 'header.php'; ?>
	<body>
	<title>Preschool Math | Enrolled Students</title>
	<body>
	<div class="container">
		<h3>Register Student</h3>
		
		<form class="form-horizontal" method="post" action="register_student.php">
		  <div class="form-group">
			<label for="username" class="col-sm-2 control-label">Username</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="username" id="username" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="f_name" class="col-sm-2 control-label">First Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="f_name" id="f_name" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="l_name" class="col-sm-2 control-label">Last Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="l_name" id="l_name" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="sex" class="col-sm-2 control-label">Sex</label>
			<div class="col-sm-10">
			  <label class="radio-inline">
				  <input type="radio" name="sex" id="male" value="M" checked="checked"> Male
				</label>
				<label class="radio-inline">
				  <input type="radio" name="sex" id="female" value="F"> Female
				</label>
			</div>
		  </div>
		  <div class="form-group">
			<label for="bday" class="col-sm-2 control-label">Birthday</label>
			<div class="col-sm-10">
			  <input type="date" class="form-control" name="bday" id="bday" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="password" class="col-sm-2 control-label">Password</label>
			<div class="col-sm-10">
			  <input type="password" class="form-control" name="password" id="password" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<div class="col-sm-offset-2 col-sm-10">
			  <button type="submit" id="registerStudentBtn" class="btn btn-default">Register</button>
			</div>
		  </div>
		</form>
		
	</div>
	</body>
	</body>
</html>