<?php
	include 'dbconnect.php';
	session_start();
	$guardian_username = $_SESSION['user'];
	$student_username = $_POST['student_username'];	
	$q = mysqli_query($conn, "SELECT id FROM user WHERE username='".$guardian_username."'");
	$row = mysqli_fetch_assoc($q);
	$guardian_id = $row['id'];
	$userCheck = mysqli_query($conn,"SELECT id FROM user WHERE username='".$student_username."'");
	
	if(mysqli_num_rows($userCheck)==0){
		if($student_username == "")
			echo "Please enter the username of the student you want to enroll.";
		else echo "User does not exist.";
	} else {
		$enrolledCheck = mysqli_query ($conn, "SELECT * FROM student_list WHERE guardian_id=".$guardian_id."
			AND student_id = (SELECT id FROM user WHERE username='".$student_username."')");
		if(mysqli_num_rows($enrolledCheck)==0){
			$add_student_list = "INSERT INTO student_list (student_id, guardian_id, type, status)
				SELECT id AS student_id,
				$guardian_id AS guardian_id,
				'S' as type,
				1 as status
				FROM user where username='".$student_username."'";
			if(mysqli_query($conn,$add_student_list))
				echo "Student has been successfully enrolled.";
			else echo "Failed to enroll student.";
		} else {
			$row = mysqli_fetch_array($enrolledCheck);
			if($row['status']==1)
				echo "Student is already enrolled.";
			else {
				$q = "update student_list set status =1 where student_id=(SELECT id FROM user WHERE username='".$student_username."')";
				mysqli_query($conn, $q);	
				echo "Student has been successfully enrolled.";
			}
		}
	}
?>