<?php
	include 'dbconnect.php';
	session_start();
	$guardian_username = $_SESSION['user'];
	$student_username = $_POST['student_username'];
	echo "user:".$student_username ;
	
	$q = mysqli_query($conn, "SELECT id FROM user WHERE username='".$guardian_username."'");
	$row = mysqli_fetch_assoc($q);
	$guardian_id = $row['id'];
	echo "id:".$guardian_id;
	$userCheck = mysqli_query($conn,"SELECT id FROM user WHERE username='".$student_username."'");
	if(mysqli_num_rows($userCheck)==0){
		echo $student_username + "User does not exist.";
	} else {
		$enrolledCheck = mysqli_query ($conn, "SELECT * FROM student_list WHERE guardian_id=".$guardian_id."
			AND student_id = (SELECT id FROM user WHERE username='".$student_username."')");
		if(mysqli_num_rows($enrolledCheck)==0){
			$add_student_list = "INSERT INTO student_list (student_id, guardian_id, type)
				SELECT id AS student_id,
				$guardian_id AS guardian_id,
				'S' as type
				FROM user where username='".$student_username."'";
			if(mysqli_query($conn,$add_student_list))
				echo "<script>alert('Successfully added student')</script>";
			else echo $student_username."add student list failed "+$add_student_list;
		} else {
			return "<script>console.log('User is already enrolled.')</script>";
		}
		//header('Location: students.php');
	}
?>