<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	<link href="datatables/media/css/datatables.css" rel="stylesheet">
	<script src="datatables/media/js/datatables.js" ></script>
	<script src="js/game.js" ></script>
	</head>
	<?php 
		include 'header.php'; 
		include 'dbconnect.php';
		$stud = $_GET['stud'];
		$game = $_GET['game']; 
		
		$get_name = mysqli_query($conn,"SELECT name FROM GAME WHERE ID=".$game);
		if(mysqli_num_rows($get_name)!=0){
			while($row =mysqli_fetch_assoc($get_name)){
				$game_name = $row['name'];
			}
		}
		
		$get_fname = mysqli_query($conn,"SELECT f_name FROM user WHERE username='".$stud."'");
		if(mysqli_num_rows($get_fname)!=0){
			while($row =mysqli_fetch_assoc($get_fname)){
				$stud_fname = $row['f_name'];
			}
		}
		
	?>
	<body>
	<title>Preschool Math | Enrolled Students</title>
	<body>
	<div class="container">
		<h3><?php echo $stud_fname."'s scores in ".$game_name ?></h3>
		<div>
		<table id="score_list" class="display" cellspacing="0" width="100%">
		
			<thead>
				<th>Date</th>
				<th>Score</th>
				<th>Rating</th>
			</thead>
			<tbody>
			<?php
				$score_list = mysqli_query($conn,"select * from score where game_id=".$game." and student_id=(select id from user where username='".$stud."')");
				if(mysqli_num_rows($score_list)!=0){
					while($row =mysqli_fetch_assoc($score_list)){
						echo "<tr>";
						$score = $row['score'];
						
						$rating = $score / 20;
						if($rating > 5) $rating = 5;
						else if ($rating < 0) $rating = 0;
						
						echo "<td>".$row['date']."</td>";
						echo "<td>".$score."</td>";
						echo "<td>";
						
						for($i=0; $i<$rating; $i++) {
							echo "<span class=\"glyphicon glyphicon-star\" aria-hidden=\"true\"></span>";
						}
						
						echo "</td>";
						
						echo "</tr>";
					}
				}
			?>
			</tbody>
		</table>
		</div>
	</div>
	</body>
	</body>
</html>