<html>
	<head>
	<script src="js/jquery.js" ></script>
	<script src="js/index.js" ></script>
	<script src="datatables/media/js/datatables.js" ></script>
	<link href="css/bootstrap.min.css" rel="stylesheet" >
	
	<script src="js/bootstrap.min.js" integrity="sha256-KXn5puMvxCw+dAYznun+drMdG1IFl3agK0p/pqT9KAo= sha512-2e8qq0ETcfWRI4HJBzQiA3UoyFk6tbNyG+qSaIBZLyW9Xf3sWZHN/lxe9fTh1U45DpPf07yj94KsUHHWe4Yk1A==" crossorigin="anonymous"></script>
	<script src="js/students.js" ></script>
	<script src="js/datatables.bootstrap.js" ></script>
	<link href="css/students.css" rel="stylesheet">
	<link href="css/index.css" rel="stylesheet">
	<link href="css/datatables.bootstrap.css" rel="stylesheet">
	<script src="js/game1.js" ></script>
	<script src="js/Chart.js"></script>
	</head>
	<?php 
		include 'header.php'; 
		include 'dbconnect.php';
		$stud = $_GET['user'];
		
		$get_name = mysqli_query($conn,"SELECT name FROM GAME WHERE ID=1");
		if(mysqli_num_rows($get_name)!=0){
			while($row =mysqli_fetch_assoc($get_name)){
				$game_name = $row['name'];
			}
		}
		
		$get_fname = mysqli_query($conn,"SELECT f_name FROM user WHERE username='".$stud."'");
		if(mysqli_num_rows($get_fname)!=0){
			while($row =mysqli_fetch_assoc($get_fname)){
				$stud_fname = $row['f_name'];
			}
		}
		
		$score_array = array();
		$chart_dates = "";
		$chart_scores = "";
		$score_list = mysqli_query($conn,"select * from score where game_id=1 and student_id=(select id from user where username='".$stud."')");
		if(mysqli_num_rows($score_list)!=0){
			for ($i=0; $row =mysqli_fetch_assoc($score_list); $i++) {
				$score_array[$i] = $row;
				$row['date'] = split(' ',$row['date'])[0];
				$chart_dates .= "'".$row['date']."',";
				$chart_scores .= $row['score'].",";
			}
		}
		
		$chart_dates = substr($chart_dates, 0, -1);
		$chart_dates = "[".$chart_dates."]";
		$chart_scores = substr($chart_scores, 0, -1);
		$chart_scores = "[".$chart_scores."]";
	?>
	<script>
		
	$(document).ready(function(){
	$('.viewselect').change(function() {
		var scores = $("#game3_table").dataTable()._('tr', {"filter":"applied"});
		console.log(scores);
	});
	
	initChart();
	function initChart() {
		lineChartData = {
			labels : <?php echo $chart_dates ?>,
			datasets : [
				{
					label: "",
					fillColor : "rgba(151,187,205,0.2)",
					strokeColor : "rgba(151,187,205,1)",
					pointColor : "rgba(151,187,205,1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(151,187,205,1)",
					data : <?php echo $chart_scores ?>
				}
			]

		}
	}	
	
		
		var ctx = document.getElementById("myChart").getContext("2d");
		chart = new Chart(ctx).Line(lineChartData, {
			responsive: true
		});

		$('#divchart1').css({left:0,top:-1000});

	});
	
	</script>
		
	
	<body>

	
	<div class="container">
		<h4><?php echo $stud_fname."'s scores in ".$game_name ?></h4>

		<div class="form-group">
		
		  <select class="form-control viewselect">
			<option selected>Table</option>
			<option>Chart</option>
		  </select>
		</div>
		
		<div style="width:70%" id="divchart1" class="container chart">
			<div>
				<canvas  id="myChart" height="450" width="600"></canvas>
			</div>
		</div>
		<table id="game1_table" class="table table-striped table-bordered" cellspacing="0" width="100%"> 
	        <thead>
	            <tr>
	                <th>Date</th>
	                <th>Score</th>
	            </tr>
	        </thead>
	        <tbody>
			<?php
				for($i=0; $i<count($score_array); $i++) {
					echo "<tr>";
					$score = $score_array[$i]['score'];
					$rating = $score / 20;
					if($rating > 5) $rating = 5;
					else if ($rating < 0) $rating = 0;
					echo "<td>".$score_array[$i]['date']."</td>";
					echo "<td>".$score."</td>";
					echo "</tr>";
				}
			?>
			</tbody>
		</table>
	</div>
	</body>
</html>