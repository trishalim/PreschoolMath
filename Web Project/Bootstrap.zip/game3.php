<html>
	<head>
	<script src="js/jquery.js" ></script>
	<script src="js/index.js" ></script>
	<script src="datatables/media/js/datatables.js" ></script>
	<link href="css/bootstrap.min.css" rel="stylesheet" >
	
	<script src="js/bootstrap.min.js" integrity="sha256-KXn5puMvxCw+dAYznun+drMdG1IFl3agK0p/pqT9KAo= sha512-2e8qq0ETcfWRI4HJBzQiA3UoyFk6tbNyG+qSaIBZLyW9Xf3sWZHN/lxe9fTh1U45DpPf07yj94KsUHHWe4Yk1A==" crossorigin="anonymous"></script>
	<script src="js/students.js" ></script>
	<script src="js/datatables.bootstrap.js" ></script>
	<link href="css/students.css" rel="stylesheet">
	<link href="css/index.css" rel="stylesheet">
	<link href="css/datatables.bootstrap.css" rel="stylesheet">
	<script src="js/game3.js" ></script>
	<script src="js/Chart.js" ></script>
	</head>
	<?php 
		include 'header.php'; 
		include 'dbconnect.php';
		$stud = $_GET['user'];
		
		$get_name = mysqli_query($conn,"SELECT name FROM GAME WHERE ID=3");
		if(mysqli_num_rows($get_name)!=0){
			while($row =mysqli_fetch_assoc($get_name)){
				$game_name = $row['name'];
			}
		}
		
		$get_fname = mysqli_query($conn,"SELECT f_name FROM user WHERE username='".$stud."'");
		if(mysqli_num_rows($get_fname)!=0){
			while($row =mysqli_fetch_assoc($get_fname)){
				$stud_fname = $row['f_name'];
			}
		}
		
		$chart = getChartData($conn, $stud, 1);
		
		function getChartData($conn, $stud, $level) {
			$chart = array();
			$chart['dates'] = "";
			$chart['scores'] = "";
			$chart['level'] = "";
			$chart['array'] = array();
			$q = "select date, score, level from score where game_id = 3 and student_id = (select id from user where username='".$stud."')";
			$score_list = mysqli_query($conn,$q);
			
			if(mysqli_num_rows($score_list)!=0){
				for ($i=0; $row =mysqli_fetch_assoc($score_list); $i++) {
					$chart['array'][$i] = $row;
					if($level == $row['level']){
						$row['date'] = split(' ',$row['date'])[0];
						$chart['dates'] .= "'".$row['date']."',";
						$chart['scores'] .= $row['score'].",";
						$chart['level'] .= $row['level'].",";	
					}
				}
			}
			$chart['dates'] = substr($chart['dates'], 0, -1);
			$chart['dates'] = "[".$chart['dates']."]";
			$chart['scores'] = substr($chart['scores'], 0, -1);
			$chart['scores'] = "[".$chart['scores']."]";
			$chart['level'] = substr($chart['level'], 0, -1);
			$chart['level'] = "[".$chart['level']."]";
			return $chart;
		}
		
		
 	?>
	
	<script>
	var lineChartData = {};
	$(document).ready(function() {
		Search("Addition");		
		lineChartData = initChart();
		var ctx = document.getElementById("myChart").getContext("2d");
		chart = new Chart(ctx).Line(lineChartData, {
			responsive: true
		});
		
		Search("Subtraction");
		lineChartData = initChart();
		var ctx2 = document.getElementById("myChart2").getContext("2d");
		chart2 = new Chart(ctx2).Line(lineChartData, {
			responsive: true
		});
		
		Search("Addition");
		$( "#game3select" ).change(function(){
			Search($( "select option:selected" ).val());
			/* chart.removeData();
			console.log("change");
			var i =0;
			var s = getScores();
			$(chart.datasets[0].points).each(function() {
				chart.datasets[0].points[i].value = s[i];
				i++;
			});
			chart.scale.xLabels = getDates();
			chart.update(); */
		});
		$('#divchart1').css({left:0,top:-1000});
		$('#divchart2').css({left:0,top:-1000});
		
	});
	
	function getScores() {
		var scores = [];
		$('.score').each(function() {
			scores.push(this.innerHTML.substring(2));
		});
		return scores;
	}
	
	function getDates() {
		var dates = [];
		$('.date').each(function() {
			dates.push(this.innerHTML.split(' ')[0]);
		});
		return dates;
	}
	
	function initChart() {
		var scores = getScores();
		var dates = getDates();
		console.log(scores);
		lineChartData = {
			labels : dates,
			datasets : [
				{
					label: "",
					fillColor : "rgba(151,187,205,0.2)",
					strokeColor : "rgba(151,187,205,1)",
					pointColor : "rgba(151,187,205,1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(151,187,205,1)",
					data : scores
				}
			]
		}
		return lineChartData;
	}	
	</script>
	<body>
	<div class="container tabular">
		<h4>
		<?php 
			echo $stud_fname."'s scores in "
		?>
		
		</h4>
		
		<div class="form-group">
		  <select class="form-control" id="game3select">
			<option selected>Addition</option>
			<option>Subtraction</option>
		  </select>
		</div>
		
		<select class="form-control viewselect">
			<option selected>Table</option>
			<option>Chart</option>
		  </select>
		
		<div style="width:70%" id="divchart1" class="container chart">
			<div>
				<canvas  id="myChart" height="450" width="600"></canvas>
			</div>
		</div>
		
		<div style="width:70%" id="divchart2" class="container chart">
			<div>
				<canvas  id="myChart2" height="450" width="600"></canvas>
			</div>
		</div>
		
		<table id="game3_table" class="table table-striped table-bordered" cellspacing="0" width="100%"> 
	        <thead>
	            <tr>
					
	                <th>Date</th>
	                <th>Score</th><th>Level</th>
	            </tr>
	        </thead>
	        <tbody>
			<?php
				
					for($i=0; $i<count($chart['array']); $i++) {
						echo "<tr>";
						$score = $chart['array'][$i]['score'];
						
						$rating = $score / 20;
						if($rating > 5) $rating = 5;
						else if ($rating < 0) $rating = 0;
						
						$level = ($chart['array'][$i]['level']==1)?"Addition":"Subtraction";
						
						echo "<td class=\"date\">".$chart['array'][$i]['date']."</td>";
						echo "<td class=\"score\">".$score."</td>";
						echo "<td>".$level."</td>";
						echo "</tr>";
					} 
				
			?>
			</tbody>
		</table>
	</div>
	</body>
</html>