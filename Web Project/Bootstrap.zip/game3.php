<html>
	<head>
	<script src="js/jquery.js" ></script>
	<script src="js/index.js" ></script>
	<script src="datatables/media/js/datatables.js" ></script>
	<link href="css/bootstrap.min.css" rel="stylesheet" >
	
	<script src="js/bootstrap.min.js" integrity="sha256-KXn5puMvxCw+dAYznun+drMdG1IFl3agK0p/pqT9KAo= sha512-2e8qq0ETcfWRI4HJBzQiA3UoyFk6tbNyG+qSaIBZLyW9Xf3sWZHN/lxe9fTh1U45DpPf07yj94KsUHHWe4Yk1A==" crossorigin="anonymous"></script>
	<script src="js/students.js" ></script>
	<script src="js/datatables.bootstrap.js" ></script>
	<link href="css/students.css" rel="stylesheet">
	<link href="css/index.css" rel="stylesheet">
	<link href="css/datatables.bootstrap.css" rel="stylesheet">
	<script src="js/game3.js" ></script>
	</head>
	<?php 
		include 'header.php'; 
		include 'dbconnect.php';
		$stud = $_GET['user'];
		
		$get_name = mysqli_query($conn,"SELECT name FROM GAME WHERE ID=3");
		if(mysqli_num_rows($get_name)!=0){
			while($row =mysqli_fetch_assoc($get_name)){
				$game_name = $row['name'];
			}
		}
		
		$get_fname = mysqli_query($conn,"SELECT f_name FROM user WHERE username='".$stud."'");
		if(mysqli_num_rows($get_fname)!=0){
			while($row =mysqli_fetch_assoc($get_fname)){
				$stud_fname = $row['f_name'];
			}
		}
		
	?>
	<body>
	<div class="container tabular">
		<h3>
		<?php 
			echo $stud_fname."'s scores in "
		?>
		
		</h3>
		
		<div class="form-group">
		  <select class="form-control" id="game3select">
			<option selected>Addition</option>
			<option>Subtraction</option>
		  </select>
		</div>
		
		<table id="game3_table" class="table table-striped table-bordered" cellspacing="0" width="100%"> 
	        <thead>
	            <tr>
					
	                <th>Date</th>
	                <th>Score</th><th>Level</th>
	            </tr>
	        </thead>
	        <tbody>
			<?php
				$score_list = mysqli_query($conn,"select date, score, level from score where game_id = 3 and student_id = (select id from user where username='".$stud."')");
				if(mysqli_num_rows($score_list)!=0){
					while($row =mysqli_fetch_assoc($score_list)){
						echo "<tr>";
						$score = $row['score'];
						
						$rating = $score / 20;
						if($rating > 5) $rating = 5;
						else if ($rating < 0) $rating = 0;
						
						$level = ($row['level']==1)?"Addition":"Subtraction";
						
						echo "<td>".$row['date']."</td>";
						echo "<td>".$score."</td>";
						echo "<td>".$level."</td>";
						echo "</tr>";
					}
				}
			?>
			</tbody>
		</table>
	</div>
	</body>
</html>