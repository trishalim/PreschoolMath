<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>
	<?php include 'header.php'; ?>
	<body>
	<title>Preschool Math | Enrolled Students</title>
	<body>
	<div class="container">
		<h3>Games</h3>
		<div>
		<?php 
			$stud = $_GET['student_username'];
		?>
		<center>
			<a href="game.php?game=1&stud=<?php echo $stud ?>"><img style="height:250px;" src="res/game1.png"></a>
			<a href="game.php?game=2&stud=<?php echo $stud ?>"><img style="height:250px;" src="res/game2.png"></a>
			<a href="game.php?game=3&stud=<?php echo $stud ?>"><img style="height:250px;" src="res/game3.png"></a>
		</center>
		</div>
	</div>
	</body>
	</body>
</html>