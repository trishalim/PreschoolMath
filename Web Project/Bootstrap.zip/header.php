<nav class="navbar navbar-default navbar-fixed-top" style="background-color:#337AB7;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button> 
          <span  onClick="history.go(-1);return true;" class="glyphicon glyphicon-chevron-left navbar-brand" style="color:#fff;"aria-hidden="true"></span>
          <a class="navbar-brand" href="index.php" style="color:#fff;">Preschool Math</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse" style="color:#fff;">
          <ul class="nav navbar-nav navbar-right">
			<li style="color:#fff;" class="navbar-text">Welcome <?php if(!isset($_SESSION)){session_start();} echo $_SESSION['user']; ?>!</li>
			<li><a style="color:#fff;" href="account.php">Account Settings</a></li>
            <li><a style="color:#fff;" href="scripts/logout.php">Log out</a></li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>
   </br>