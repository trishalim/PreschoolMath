<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>

	<body>
	<div class="container">

      <form class="form-signin" action="login.php" method="POST">
        <h2 class="form-signin-heading">Preschool Math</h2>
        <label for="user" class="sr-only">Username</label>
        <input type="text" name="user" id="user" class="form-control" placeholder="Username" required autofocus>
        <label for="pw" class="sr-only">Password</label>
        <input type="password" name="pw" id="pw" class="form-control" placeholder="Password" required>
        <button class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
		<p><center>Not yet registered? <a href="register_guardian.php">Sign up now.</a></center></p>
      </form>
	<?php
	
		if(isset($_GET['error_msg']))
			echo $_GET['error_msg'];
		if(isset($_SESSION['user'])){
			header('Location: students.php');
			echo "logged in";
		} else {
			echo "not logged in";
		}
			
	?>
    </div> 
	</body>
</html>