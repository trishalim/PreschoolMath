<?php

	session_start();
	if(isset($_SESSION['user'])){
		include 'students.php';
	}
	else {
		include 'login.php';
	}

?>