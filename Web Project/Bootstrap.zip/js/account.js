$(document).ready(function(){
	$('#saveGuardianBtn').hide();
	$('#editGuardianBtn').click(function(){
		//$(this).parent().parent().siblings().find(':input').attr("disabled", false);
		$('#egf_name').attr("disabled", false);
		$('#egl_name').attr("disabled", false);
		$('#editGuardianBtn').hide();
		$('#saveGuardianBtn').show();
		$('#cancel').show();
		edit();
	});
});

function edit() {
	$("#edit_acct").validate({
		required: true,
		rules: {
			egf_name: {
				minlength: 5,
				maxlength: 30
			},
			egl_name: {
				minlength: 2,
				maxlength: 30
			}
		}
	});
}