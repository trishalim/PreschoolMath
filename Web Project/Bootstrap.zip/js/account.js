$(document).ready(function(){
	$('#egpassword').hide();
	$('#egpasswordfield').hide();
	$('#saveGuardianBtn').hide();
	$('#editGuardianBtn').click(function(){
		$(this).parent().parent().siblings().find(':input').attr("disabled", false);
		$('#editGuardianBtn').hide();
		$('#saveGuardianBtn').show();
	});
	$('#changePw').click(function(){
		$('#egpassword').show();
		$('#egpasswordfield').show();
		$('#changePw').hide();
		$('#pwLabel').html("Current Password");
	});
});