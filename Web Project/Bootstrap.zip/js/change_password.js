$(document).ready(function(){

	$.validator.addMethod(
	    "correct",
	    function(value) {
	    	var username = $('#edit_user').html();
	    	var pw = $('#password').val();
	    	var data = {
	    		username: username,
	    		pw: pw
	    	}
	        var match = false;
	        var jqXHR = $.ajax({
	        	type: 'post',
	        	url: 'scripts/match.php',
	        	data: data,
	        	success: function(data) {
	        		console.log(data);
	        		return data;
	        	},
	        	async: false
	        });
	        match = jqXHR.responseText;
	        if(match == "true")
	        	match = true;
	        else match = false;
	        console.log(match);
	        return match;	
	    }
	);

	$('#change_password').validate({
		rules: {
			password: { 
				required: true,
				minlength: 5,
				maxlength: 15,
				correct: true 
			},
			password1: {
				required: true,
				minlength: 5,
				maxlength: 15
			},
			password2: {
				required: true,
				minlength: 5,
				maxlength: 15,
				equalTo: "#password1"
			}
		},
		messages: {
			password: { 
				correct: "Invalid password."
			},
			password2: {
				equalTo: "Passwords don't match."
			}
		}
	});
});