$(document).ready(function(){
	$.validator.addMethod(
	    "regex",
	    function(value, element, regexp) {
	        var check = false;
	        return this.optional(element) || regexp.test(value);
	    }
	);

	$.validator.addMethod(
	    "available",
	    function(value) {
	        var avail = false;
	        var jqXHR = $.ajax({
	        	type: 'post',
	        	url: 'scripts/username_avail.php',
	        	data: {username:value},
	        	success: function(data, self) {
	        		return data;
	        	},
	        	async: false
	        });
	        avail = jqXHR.responseText;
	        if(avail == "true")
	        	avail = true;
	        else avail = false;
	        return avail;	
	    }
	);
	
	$("#create_student").validate({
		required: "true",
		rules: {
			username: {
				available: true,
				regex:  /^[a-zA-Z0-9]+$/,
				minlength: 5,
				maxlength: 15
			},
			f_name: {
				regex:  /^[A-Za-z ]+$/,
				minlength: 5,
				maxlength: 30
			},
			l_name: {
				regex:  /^[A-Za-z ]+$/,
				minlength: 2,
				maxlength: 30
			},
			password: {
				minlength: 5,
				maxlength: 15
			},
			password2: {
				required: true,
				minlength: 5,
				maxlength: 15,
				equalTo: "#password"
			}
		},
		messages: {
			username: {
				available: "Username is not available.",
				regex:  "Please enter only letters A-Z or a-z and numbers."
			},
			f_name: {
				regex: "Please enter only letters and spaces."
			},
			l_name: {
				regex: "Please enter only letters and spaces."
			},
			password2: {
				equalTo: "Passwords don't match."
			}
		}
	});

});
