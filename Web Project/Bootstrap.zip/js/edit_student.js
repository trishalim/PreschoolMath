$(document).ready(function() {
	$('#saveStudentBtn').click(function(){
		//TODO: validations
		
		var student_username = $('#eusername').val();
		var f_name = $('#ef_name').val();
		var l_name = $('#el_name').val();
		var sex = $('#esex').val();
		var bday = $('#ebday').val();
		var data = {
			student_username: student_username,
			f_name: f_name,
			l_name: l_name,
			sex: sex,
			bday: bday
		};
		console.log(data);
		$.ajax({
			url: "scripts/edit_student.php",
			data: data,
			type: "POST",
			dataType: "json",
			success: function(data) {
				console.log("success",data);
			}
		})
		//location = "students.php";
	});
});