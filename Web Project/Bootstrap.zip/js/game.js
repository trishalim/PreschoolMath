$(document).ready(function() {
	$('#score_list').DataTable( {
		dom: 'tip',
		pageLength: 5
	});
});