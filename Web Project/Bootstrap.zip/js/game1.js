$(document).ready(function(){
	var game1_table = $('#game1_table').DataTable({
		dom: '<"wrapper"t><"toolbar">p',
		pageLength: 5,
		columns: [
					{ 
						
					},
					{
						"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
							$(nTd).html("&#9899; "+oData[1]);
							rateNoLink(nTd);
						}
					},
		],
		oLanguage: {
			"sEmptyTable":     "Student has not played this game yet."
		}
	});
	$("div.toolbar").html('<span>Legend: &nbsp; <span class=\"developing\">&#9899;</span> Developing (0-59) &nbsp; <span class=\"satisfactory\">&#9899;</span> Satisfactory (60-79) &nbsp; <span class=\"excellent\">&#9899;</span> Excellent (80-100) </span>');
	$('th').css('text-align','center');
	
	$('#myChart').hide();
	$('.viewselect').change(function(){
		console.log("change");
		$('#myChart').toggle();		
		$('#game1_table_wrapper').toggle();
		
	});

});