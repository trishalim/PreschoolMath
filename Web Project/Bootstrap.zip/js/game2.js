$(document).ready(function(){
	var game2_table = $('#game2_table').DataTable({
		dom: '<"wrapper"t><"toolbar">p',
		pageLength: 5,
		//columnDefs: [{ "visible": false,  "targets": [ 2 ] }],
		columns: [
			
			{},
			{
				"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
					$(nTd).html("&#9899; "+oData[1]);
					rateNoLink(nTd);
				}
			},
			{}
		],
		oLanguage: {
			"sZeroRecords": "Student has not played this level yet.",
			"sEmptyTable":     "Student has not played this game yet."
		}
	});
	$("div.toolbar").html('<span>Legend: &nbsp; <span class=\"developing\">&#9899;</span> Developing (0-59) &nbsp; <span class=\"satisfactory\">&#9899;</span> Satisfactory (60-79) &nbsp; <span class=\"excellent\">&#9899;</span> Excellent (80-100) </span>');
	$('th').css('text-align','center');
	
	$( "#game2select" ).change(function(){
		Search($( "select option:selected" ).val());
	});
	$('.viewselect, #game2select').change(function(){
		updateView();
	});
	
	
	var data = initChart();
	var ctx = [];
	var chart = [];
	
	for(var i=1;i<11;i++) {
		Search(""+i);
		data = initChart();
		ctx[i] = document.getElementById("chart"+i).getContext("2d");
		chart[i] = new Chart(ctx[i]).Line(data, {
			responsive: true
		});
	} 
	
	Search("1");

	$('.chart').hide();
});

function updateView() {
	console.log("oasjkas");
	var view = $('.viewselect :selected').val();
		var level = $('#game2select :selected').val();
		if(view == "Chart") {
			$('#game2_table_wrapper').hide();
			$('.chart').hide();
			var str = "#chart"+level;
			console.log(str);
			$(str).show();
			str = "#divchart"+level;
			console.log(str);
			$(str).show();
		} else if (view=="Table"){
			$('.chart').hide();
			$('#game2_table_wrapper').show();
		} 
	
}

function initChart() {
	var scores = getScores();
	var dates = getDates();
	var data  = {
			labels : dates,
			datasets : [
				{
					label: "",
					fillColor : "rgba(151,187,205,0.2)",
					strokeColor : "rgba(151,187,205,1)",
					pointColor : "rgba(151,187,205,1)",
					pointStrokeColor : "#fff",
					pointHighlightFill : "#fff",
					pointHighlightStroke : "rgba(151,187,205,1)",
					data : scores
				}
			]
		};
		
	return data;
}

	function getScores() {
		var scores = [];
		$('.score').each(function() {
			scores.push(this.innerHTML.substring(2));
		});
		return scores;
	}
	
	function getDates() {
		var dates = [];
		$('.date').each(function() {
			dates.push(this.innerHTML.split(' ')[0]);
		});
		return dates;
	}
	
	
function Clear() {    
     $('#game2_table tr').show();
}

function Search(word) {
    Clear();
	$('#game2_table').DataTable().column(2).search(word).draw();
 }