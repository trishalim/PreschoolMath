$(document).ready(function(){
	var game3_table = $('#game3_table').DataTable({
		dom: '<"wrapper"t><"toolbar">p',
		pageLength: 5,
		columnDefs: [{ "visible": false,  "targets": [ 2 ] }],
		columns: [
			
			{},
			{
				"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
					$(nTd).html("&#9899; "+oData[1]);
					rateNoLink(nTd);
				}
			},
			{}
		],
		oLanguage: {
			"sZeroRecords": "Student has not played this level yet.",
			"sEmptyTable":     "Student has not played this game yet."
		}
	});
	$("div.toolbar").html('<span>Legend: &nbsp; <span class=\"developing\">&#9899;</span> Developing (0-59) &nbsp; <span class=\"satisfactory\">&#9899;</span> Satisfactory (60-79) &nbsp; <span class=\"excellent\">&#9899;</span> Excellent (80-100) </span>');
	$('th').css('text-align','center');
	Search("Addition");
	$( "#game3select" ).change(function(){
		Search($( "select option:selected" ).val());
	});
});

function Clear() {    
     $('#game3_table tr').show();
}

function Search(word) {
    Clear();
	$('#game3_table').DataTable().column(2).search(word).draw();
 }