$(document).ready(function(){
	var game3_table = $('#game3_table').DataTable({
		dom: '<"wrapper"t><"toolbar">p',
		pageLength: 5,
		columnDefs: [{ "visible": false,  "targets": [ 2 ] }],
		columns: [
			
			{},
			{
				"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
					$(nTd).html("&#9899; "+oData[1]);
					rateNoLink(nTd);
				}
			},
			{}
		],
		oLanguage: {
			"sZeroRecords": "Student has not played this level yet.",
			"sEmptyTable":     "Student has not played this game yet."
		}
	});
	$("div.toolbar").html('<span>Legend: &nbsp; <span class=\"developing\">&#9899;</span> Developing (0-59) &nbsp; <span class=\"satisfactory\">&#9899;</span> Satisfactory (60-79) &nbsp; <span class=\"excellent\">&#9899;</span> Excellent (80-100) </span>');
	$('th').css('text-align','center');
	//Search("Addition");
	$('#myChart').hide();
	$('#myChart2').hide();
	$('.viewselect, #game3select').change(function(){
		/* console.log("change");
		$('#myChart').toggle();	*/	
		//$('#game3_table_wrapper').toggle(); 
		updateView();
	});
	
	function updateView() {
		var view = $('.viewselect :selected').val();
		var level = $('#game3select :selected').val();
		if(view == "Table"){
			Search(level);
			$('#game3_table_wrapper').show();
			$('#myChart').hide();
			$('#myChart2').hide();
		}
		else if (view == "Chart"){
			$('#game3_table_wrapper').hide();
			if(level=="Addition"){
				console.log("chart add");
				$('#myChart').show();
				$('#myChart2').hide();
			}
			else {
				console.log("chart minus");
				$('#myChart2').show();
				$('#myChart').hide();
			}
				
		}
			
	}
});

function Clear() {    
     $('#game3_table tr').show();
}

function Search(word) {
    Clear();
	$('#game3_table').DataTable().column(2).search(word).draw();
 }