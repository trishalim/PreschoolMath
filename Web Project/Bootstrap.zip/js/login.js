$(document).ready(function(){
	$('#signInBtn').on('click', function(){
		console.log('click');
		var user = $('#user').val();
		var pw = $('#pw').val();
		var data = {
			user : user,
			pw: pw
		};
		$.ajax({
			type : "post",
			url : "scripts/login.php",
			data : data,
			success : function(data) {
				$('#error').html(data);
				if (data == "") {
					$('#errorDiv').hide();
					location.reload();
				}
				else 
					$('#errorDiv').show();
			},
		})
	});

	$('#errorDiv').hide();
});