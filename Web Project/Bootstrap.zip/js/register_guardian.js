
$(document).ready(function() {
	 /*$('#registerGuardianBtn').click(function(){
		var error;
		var gpassword = $('#gpassword').val();
		var gcpassword = $('#gcpassword').val();
			var data = {
				gusername : $('#gusername').val(),
				gf_name : $('#gf_name').val(),
				gl_name : $('#gl_name').val(),
				gpassword : $('#gpassword').val(),
				gcpassword : $('#gcpassword').val()
			};
			$.ajax({
				type : 'post',
				url : 'scripts/register_guardian.php',
				data : data,
				success : function(data) {
					$('#error').html(data);
				}
			});
			
		
	});*/

	$.validator.addMethod(
	    "regex",
	    function(value, element, regexp) {
	        var check = false;
	        return this.optional(element) || regexp.test(value);
	    }
	);

	$.validator.addMethod(
	    "available",
	    function(value) {
	        var avail = false;
	        var jqXHR = $.ajax({
	        	type: 'post',
	        	url: 'scripts/username_avail.php',
	        	data: {username:value},
	        	success: function(data, self) {
	        		return data;
	        	},
	        	async: false
	        });
	        avail = jqXHR.responseText;
	        if(avail == "true")
	        	avail = true;
	        else avail = false;
	        return avail;	
	    }
	);
	
	$("#form").validate({
		required: "true",
		rules: {
			gusername: {
				available: true,
				regex:  /^[a-zA-Z0-9]+$/,
				minlength: 5,
				maxlength: 15
			},
			gf_name: {
				regex: /^[A-Za-z ]+$/,
				minlength: 5,
				maxlength: 30
			},
			gl_name: {
				regex: /^[A-Za-z ]+$/,
				minlength: 2,
				maxlength: 30
			},
			gpassword: {
				required: true,
				minlength: 5,
				maxlength: 15
			},
			gcpassword: {
				required: true,
				minlength: 5,
				maxlength: 15,
				equalTo: "#gpassword"
			}
		},
		messages: {
			gusername: {
				available: "Username is not available.",
				regex:  "Please enter only letters A-Z or a-z and numbers."
			},
			gf_name: {
				regex: "Please enter only letters and spaces."
			},
			gl_name: {
				regex: "Please enter only letters and spaces."
			},
			gcpassword: {
				equalTo: "Passwords don't match."
			}
		}
	});

});