

$(document).ready(function() {
	 $('#registerGuardianBtn').click(function(){
		
	});
});