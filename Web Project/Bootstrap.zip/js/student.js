$(document).ready(function(){

	$('#editBtn, #rCancelBtn').on('click', function(){
		console.log("edit");
		toggleEdit();
	});
	$.validator.addMethod(
	    "regex",
	    function(value, element, regexp) {
	        var retval= this.optional(element) || regexp.test(value);
	        console.log(regexp);
	        console.log(value);
	        console.log(retval);
	        return retval;
	    }
	);
	$("#student").validate({
		required: true,
		rules: {
			ef_name: {
				regex:  /^[A-Za-z ]+$/,
				minlength: 5,
				maxlength: 30
			},
			el_name: {
				regex:  /^[A-Za-z ]+$/,
				minlength: 2,
				maxlength: 30
			}
		},
		messages: {
			ef_name: {
				regex: "Please enter only letters and spaces."
			},
			el_name: {
				regex: "Please enter only letters and spaces." 
			}
		}
	});
});


	

function edit() {

	
}

function editStudent(data) {
	$.ajax({
			type: 'post',
			url: 'scripts/edit_student.php',
			data: data,
			success: function(data) {
				console.log(data);
				data = JSON.parse(data);
				data.sex = (data.sex=='F')?"Female":"Male";
				$('.fname').html(data.f_name);
				$('.lname').html(data.l_name);
				$('.sex').html(data.sex);
				$('.bday').html(data.bday);
				if(data.msg == "success"){
					toggleEdit();
					$('.changepw').hide();
					$('#errorDiv').hide();
					$('.beforeChangePw').hide();	
				} else {
					$('#error').html(data.msg);
					$('#errorDiv').show();
				}
			}
		});
}

function toggleEdit() {
	$('.view, .edit').toggle();
}