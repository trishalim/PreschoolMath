$(document).ready(function(){
	$('#editBtn').on('click', function(){
		console.log("edit");
		toggleEdit();
	});
	$('#rCancelBtn').on('click', function(){
		toggleEdit();
	});
	$('#saveStudentBtn').on('click', function(){
		toggleEdit();
	});
});

function toggleEdit() {
	$('.view, .edit').toggle();
}