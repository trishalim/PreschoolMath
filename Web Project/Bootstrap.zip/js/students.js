 //var dataset = "[";
 var dataset = "";
 var sTable;
 $(document).ready(function() {
	setStudentList();
	initStudentsList();
    $('#search_student').keyup(function(){
      sTable.search($(this).val()).draw() ;
    });
	
	//enroll
	$('#enrollBtn').click(function(){
		var data = {};
		data.student_username = $('#enroll_user').val();
		$.ajax({
			url: "enroll.php",
			data: data,
			dataType: "json",
			type: "POST",
			success: function(data) {
				setStudentList();
				console.log(data);
			},
			error: setStudentList,
			async: false
		});
	});
	
	$('.viewScoresBtn').click(function(){
		var student_username = $(this).parent().siblings().html();
		location = "games.php?student_username="+student_username;
	});
	
	$('.editStudentBtn').click(function(){
		var student_username = $(this).parent().siblings().html();
		location = "edit_student.php?student_username="+student_username;
	});
	
	function setStudentList() {
		dataset = "[";
		$.ajax({
			url: "scripts/students.php",
			dataType: "json",
			type: "GET",
			success: function (data) {
				for(var i=0; i<data.length; i++) {
					dataset += "[\"" + data[i].username +  "\"," 
						+"\""+data[i].game_ave[0]+ "\"," 
						+"\""+data[i].game_ave[1]+ "\"," 
						+"\""+data[i].game_ave[2]+ "\"," 
						+"\""+data[i].game_ave[3]+ 
						"\"],";
				}
			},
			error: function(ts) { alert(ts.responseText) },
 			async: false
		});
		dataset = dataset.slice(0, -1);
		if (dataset!==""){
			dataset += "]";
			dataset = JSON.parse(dataset);
		}
		if($.fn.DataTable.isDataTable( '#students_list' ) ) {
			sTable.destroy();
			initStudentsList();
		}
	}
	
	
} );
var bday1;
function getAge(bday) {
	console.log(bday);
	bday1= bday;
	var today = new Date();
    var birthDate = new Date(bday);
    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }
	if(age<0) age = 0;
	return age;
}

	function initStudentsList() {
		sTable= $('#students_list').DataTable( {
				dom: '<"wrapper"t><"toolbar">p',
				data: dataset,
				pageLength: 5,
				order: [[ 4, "desc" ]],
				columnDefs: [ {
					visible: false
					
				} ],
				columns: [
					{ 
						"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
							$(nTd).html("<a href='student.php?user="+oData[0]+"'>"+oData[0]+"</a>");
						}
					},
					{
						"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
							$(nTd).html("&#9899; <a href='game1.php?user="+oData[0]+"'>"+oData[1]+"</a>");
							rate(nTd);
						}
					},
					{ 
						"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
							$(nTd).html("&#9899; <a href='game2.php?user="+oData[0]+"'>"+oData[2]+"</a>");
							rate(nTd);
						}
					},
					{ 
						"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
							$(nTd).html("&#9899; <a href='game3.php?user="+oData[0]+"'>"+oData[3]+"</a>");
							rate(nTd);
						}
					},
					{ 
						"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
							$(nTd).html("&#9899; "+oData[4]);
							rateNoLink(nTd);
						}
					},
				],
				"render" : function(data, type, row, meta){
					if(type === 'display'){
					   return $('<a>')
						  .attr('href', data)
						  .text(data)
						  .wrap('<div></div>')
						  .parent()
						  .html();

					} else {
					   return data;
					}
				},
				"fnCreatedRow": function( nRow, aData, iDataIndex ) {
					   //$('td:eq(4)', nRow).html("<button type=\"button\" class=\"btn btn-default editStudentBtn\">Edit</button>");
				},
		} ); 
		$("div.toolbar").html('<span>Legend: &nbsp; <span class=\"developing\">&#9899;</span> Developing (0-59) &nbsp; <span class=\"satisfactory\">&#9899;</span> Satisfactory (60-79) &nbsp; <span class=\"excellent\">&#9899;</span> Excellent (80-100) </span>');
		$('th').css('text-align','center');
	}
	
function rate(cell) {
	var score = $(cell).find('a').html();
	if(score>=80) {
		$(cell).addClass("excellent");
	} else if(score>=60) {
		$(cell).addClass("satisfactory");
	} else if(score<60) {
		$(cell).addClass("developing");
	}
}

function rateNoLink(cell) {
	var score = $(cell).html().split(' ')[1];
	if(score>=80) {
		$(cell).addClass("excellent");
	} else if(score>=60) {
		$(cell).addClass("satisfactory");
	} else if(score<60) {
		$(cell).addClass("developing");
	}
}
	
	
