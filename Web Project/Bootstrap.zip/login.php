<?php
	include 'dbconnect.php';
	$user =  $_POST['user'];
	$pw = $_POST['pw'];
	echo $user;
	session_start();
	
	$check = mysqli_query($conn,"SELECT * FROM user WHERE username='".$user."'");
	if (mysqli_num_rows($check)==0)
	{
		//echo "hi";
		header('Location: http://preschoolmath.x10host.com?error_msg=Does not exist');
	}
	else
	{
		//echo "else";
		while($row = mysqli_fetch_assoc($check)){
			if($row['type']=='G'){
				$pwcheck = mysqli_query($conn,"SELECT password FROM guardian where id='".$row['id']."'");
				$row1 = mysqli_fetch_assoc($pwcheck);
				if($row1['password']==$pw){
					echo "Login success";
					header("Location: students.php");
					$_SESSION['user'] = $user;
					die();
				} else {
					echo "Guardian, but invalid password.";
					header('Location: http://preschoolmath.x10host.com?error_msg=Wrong password');
				}
			} else {
				header('Location: http://preschoolmath.x10host.com?error_msg=Not a guardian');
			}
		}
	}

?>