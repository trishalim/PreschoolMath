<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<script src="js/login.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>

	<body>
	<div class="container">

      <center><img style="width:30%;" src="res/icon.png"></img></center>
      <form class="form-signin" action="index.php">
        <label for="user" class="sr-only">Username</label>
        <input type="text" id="user" name="user" id="user" class="form-control" placeholder="Username" required autofocus>
        <label for="pw" class="sr-only">Password</label>
        <input type="password" name="pw" id="pw" class="form-control" placeholder="Password" required>
        <button id="signInBtn" class="btn btn-lg btn-primary btn-block" type="button">Sign in</button>
		<p><center>Not yet registered? <a href="register_guardian.php">Sign up now.</a></center></p>
		<div class="alert alert-danger" role="alert" id="errorDiv">
		  <span class="glyphicon glyphicon-exclamation-sign" aria-hidden="true"></span>
		  <span class="sr-only">Error:</span>
		  <span id="error"></span>
		</div>
      </form>
	
    </div> 
	</body>
</html>