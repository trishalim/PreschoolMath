<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/form.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/index.js" ></script>
	<script src="js/register_guardian.js" ></script>
	<script src="js/jquery.validate.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>

	<body>
	<title>Preschool Math | Register as Guardian</title>
	<body>
	<div class="container" style="margin-top: -30px;">
		<h4>Register as Guardian</h4>
		
		<form class="form-horizontal" id="form" method="post" action="scripts/register_guardian.php">
		  <div class="form-group">
			<label for="username" class="col-sm-2 control-label">Username</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="gusername" id="gusername" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="f_name" class="col-sm-2 control-label">First Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="gf_name" id="gf_name" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="l_name" class="col-sm-2 control-label">Last Name</label>
			<div class="col-sm-10">
			  <input type="text" class="form-control" name="gl_name" id="gl_name" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="password" class="col-sm-2 control-label">Password</label>
			<div class="col-sm-10">
			  <input type="password" class="form-control" name="gpassword" id="gpassword" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="cpassword" class="col-sm-2 control-label">Confirm password</label>
			<div class="col-sm-10">
			  <input type="password" class="form-control" name="gcpassword" id="gcpassword" required="true">
			</div>
		  </div>
		  <div id="error">

		  </div>
		  <div class="modal-footer">
			<div class="col-sm-offset-2 col-sm-10">
			  <button id="registerGuardianBtn" class="btn btn-primary" type="submit">Register</button>
			</div>
		  </div>
		</form>
		
	</div>
	</body>
	</body>
</html>