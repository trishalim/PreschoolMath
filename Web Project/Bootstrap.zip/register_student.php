 <?php 
	include 'dbconnect.php';
	session_start();
	$username = $_POST['username'];
	$f_name = $_POST['f_name'];
	$l_name = $_POST['l_name'];
	$birth_date = $_POST['bday'];
	/* $month = $_POST['month'];
	$day = $_POST['day'];
	$year = $_POST['year']; */
	$sex = $_POST['sex'];
	$password = $_POST['password'];
	$guardian_username = $_SESSION['user'];
	//$birth_date = $year."-".$month."-".$day;
	$msg="";
	echo $username.$f_name.$l_name.$birth_date.$sex.$guardian_username;
	
	$userCheck = mysqli_query($conn,"SELECT * FROM user WHERE username='".$username."'");
	if(mysqli_num_rows($userCheck)==0){
		$q = mysqli_query($conn, "SELECT id FROM user WHERE username='".$guardian_username."'");
		echo $guardian_username;
		$row = mysqli_fetch_assoc($q);
		$guardian_id = $row['id'];
		
		$user_data = "'".$username."',".
				"'".$f_name."',".
				"'".$l_name."',". 
				"'".$password."',". 
				"'S'";
		$add_user = "INSERT INTO user (username,f_name,l_name,password,type,status) values (".$user_data.",1)";
		if(mysqli_query($conn,$add_user))
			echo "added user";
		else exit("add user failed ".$add_user);
		
		$add_student = "INSERT INTO student (user_id, birth_date, sex, primary_guardian)
			SELECT id AS user_id, 
			'".$birth_date."' AS birth_date,
			'".$sex."' AS sex,
			'".$guardian_id."' AS primary_guardian
			FROM user where username='".$username."'";
		if(mysqli_query($conn,$add_student))
			echo "added student";
		else exit("add student failed ".$add_student);
		
		$add_student_list = "INSERT INTO student_list (student_id, guardian_id, type,status)
			SELECT id AS student_id,
			$guardian_id AS guardian_id,
			'P' as type,
			1 as status
			FROM user where username='".$username."'";
		if(mysqli_query($conn,$add_student_list))
			echo "added student list";
		else echo "add student list failed ".$add_student_list;
	} else {
		$msg = "Username already exists.";
		header('Location: create_student.php?msg='.$msg);
	}
	
	header('Location: students.php');
 ?>