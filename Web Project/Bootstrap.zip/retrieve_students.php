<?php
			include('dbconnect.php');
			session_start();
			$guardian_username = $_SESSION['user'];
			$get_students = "select u.id, u.username, u.f_name, u.l_name, s.birth_date, s.sex from user u, student s 
				where s.user_id=u.id and u.id IN 
				(select student_id from student_list where guardian_id = 
				(select id from user where username='".$guardian_username."'))";
				
			$student_list = mysqli_query($conn, $get_students);
			if(mysqli_num_rows($student_list)==0){
				echo "No students enrolled.";
			} else {
				$emparray = array();
				while($row =mysqli_fetch_assoc($student_list))
				{
					$emparray[] = $row;
				}
				 echo json_encode($emparray);
			}
		?>