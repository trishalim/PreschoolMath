<?php

	include 'dbconnect.php';
	$username = $_GET['username'];
	$pw = $_POST['password1'];
	echo $pw;

	$q = "update user set password='".$pw."' where username='".$username."'";
	mysqli_query($conn,$q);

	session_start();
	if($_SESSION['user']==$username)
		header('Location: ../account.php');
	else header ('Location: ../student.php?user='.$username);
?>