<?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbName = "thesis";
	$conn = new mysqli($servername, $username, $password, $dbName);
?>