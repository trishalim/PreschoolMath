<?php

	include 'dbconnect.php';
	session_start();
	$user = $_SESSION['user'];
	$f_name = $_POST['egf_name'];
	$l_name = $_POST['egl_name'];
	$q = "update user set f_name='".$f_name."', l_name='".$l_name."' where username='".$user."'";
	echo $q;
	mysqli_query($conn, $q);
	header ('Location: ../account.php?user='.$user);
?>