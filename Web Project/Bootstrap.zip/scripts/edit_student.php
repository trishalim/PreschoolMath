<?php
	include '../dbconnect.php';
	//$guardian_username = $_POST['guardian_username'];
	$student_username = $_GET['eusername'];
	
	$f_name = $_POST['ef_name'];
	$l_name = $_POST['el_name'];
	$bday = $_POST['ebday'];
	$sex = $_POST['esex'];
	
	echo $f_name.$l_name.$student_username;
	
	$q = "update user set f_name='"+ $f_name  +"', l_name='"+ $l_name +"' where username='"+ $student_username +"'";
	$result = mysqli_query($conn, $q);
	if (!$result) {
    die('Invalid query: ' . mysqli_error($result));
}
	
	$q = "update student set birth_date='"+$bday+"', sex='"+$sex+"' where user_id=(select id from user where username ='"+ $student_username +"')";
	mysqli_query($conn, $q);
	
?>