<?php
	include 'dbconnect.php';
/*	$changepw = false;
	$success_changepw = null; 
	$student_username = $_POST['student_username'];	
	$f_name = $_POST['f_name'];
	$l_name = $_POST['l_name'];
	$bday = $_POST['bday'];
	$sex = $_POST['sex'];
	$data = array();
	$msg = "";
	$pw;
	if(isset( $_POST['oldpw'])){
		$changepw = true;
		$oldpw = $_POST['oldpw'];
		$newpw = $_POST['newpw'];
		$newpw2 = $_POST['newpw2'];
		$q = "select password from user where username='".$student_username."'";
		$data['q'] = $q;
		$r  = mysqli_query($conn, $q);
		$row = mysqli_fetch_array($r);
		$pw = $row['password'];
		if($newpw == "" || $newpw2 == "" ) {
			$msg = "All fields are required.";
		} else if($oldpw == $row['password']){
			$success_changepw = true;
			$msg = "success";
			$q = "update user set f_name='".$f_name."', l_name='".$l_name."', password='".$newpw."' where username='".$student_username."'";

		} else {
			$msg = "Current password is incorrect.";
			$success_changepw = true;
			$q = "update user set f_name='".$f_name."', l_name='".$l_name."' where username='".$student_username."'";
		}
	} else {
		$q = "update user set f_name='".$f_name."', l_name='".$l_name."' where username='".$student_username."'";
	}

	$result = mysqli_query($conn, $q);
	if (!$result) {
		die('Invalid query: ' . mysqli_error($result));
	} 
	
	$q = "update student set birth_date='".$bday."', sex='".$sex."' where user_id=(select id from user where username ='".$student_username."')";
	mysqli_query($conn, $q);

	
	$data['f_name'] = $f_name;
	$data['l_name'] = $l_name;
	$data['bday'] = $bday;
	$data['sex'] = $sex;
	$data['success_changepw'] = $success_changepw;
	$data['msg'] = $msg;
	echo json_encode($data);*/
	$user = $_GET['eusername'];
	$f_name = $_POST['ef_name'];
	$l_name = $_POST['el_name'];
	$bday = $_POST['ebday'];
	$sex = $_POST['esex'];

	$user_id = "(select id from user where username='".$user."')";
	$q = "update user set f_name='".$f_name."', l_name='".$l_name."' where username='".$user."'";
	echo $q."<br>";
	mysqli_query($conn,$q);
	$q = "update student set bday='".$bday."', sex='".$sex."' where user_id=".$user_id;
	echo $q;
	mysqli_query($conn,$q);
	header('Location: ../student.php?user='.$user);
?>