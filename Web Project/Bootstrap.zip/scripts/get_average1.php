<?php
	include('../dbconnect.php');
	$query_str = "select AVG(score) as avg from score where game_id = 1 and student_id =(select id from user where username='".$_GET['username']."')";
	$score_list = mysqli_query($conn, $query_str);
	if(mysqli_num_rows($score_list)==0){
		echo "No students enrolled.";
	} else {
		/* $emparray = array();
		while($row =mysqli_fetch_assoc($score_list)){
			$emparray[] = $row;
		}
		$json = json_encode($emparray); */
		$score = mysqli_fetch_row($score_list);
		echo $score[0];
	}	
?>