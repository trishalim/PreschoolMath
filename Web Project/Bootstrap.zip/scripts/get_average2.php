<?php
	include('../dbconnect.php');
	
	$score_array = array();
	$overall_average = 0;
	for($i=1;$i<=10;$i++){
		$query_str = "select AVG(score) as avg from score where game_id = 2
			and level=".$i."
			and student_id =(select id from user where username='".$_GET['username']."')";
		$score_list = mysqli_query($conn, $query_str);
		if(mysqli_num_rows($score_list)==0){
			echo "No students enrolled.";
		} else {
			$score_array[$i] = array();
			while($row =mysqli_fetch_assoc($score_list)){
				if($row['avg']==null)
					$row['avg'] = 0;
				$score_array[$i] = $row;
				$overall_average += $row['avg'];
			}
			
			/* $json = json_encode($score_array[$i]);
			echo $json;
			echo "<script>console.log(".$json.")</script>"; */
			//echo $score_array[$i];
		}
	}
	echo $overall_average/10;
	//echo json_encode($score_array);
	
?>