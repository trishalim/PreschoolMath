<?php

	include '../dbconnect.php';
	
	$stud = $_GET['stud'];
	$level = $_GET['level'];

	getChartData($conn, $stud, $level);

	function getChartData($conn, $stud, $level) {
			$chart = array();
			$chart['dates'] = "";
			$chart['scores'] = "";
			$chart['level'] = "";
			$chart['array'] = array();
			$q = "select date, score, level from score where game_id = 3 and student_id = (select id from user where username='".$stud."')";
			$score_list = mysqli_query($conn,$q);
			
			if(mysqli_num_rows($score_list)!=0){
				for ($i=0; $row =mysqli_fetch_assoc($score_list); $i++) {
					$chart['array'][$i] = $row;
					if($level == $row['level']){
						$row['date'] = split(' ',$row['date'])[0];
						$chart['dates'] .= "'".$row['date']."',";
						$chart['scores'] .= $row['score'].",";
						$chart['level'] .= $row['level'].",";	
					}
				}
			}
			$chart['dates'] = substr($chart['dates'], 0, -1);
			$chart['dates'] = "[".$chart['dates']."]";
			$chart['scores'] = substr($chart['scores'], 0, -1);
			$chart['scores'] = "[".$chart['scores']."]";
			$chart['level'] = substr($chart['level'], 0, -1);
			$chart['level'] = "[".$chart['level']."]";
			echo json_encode($chart);
			return $chart;
		}


?>