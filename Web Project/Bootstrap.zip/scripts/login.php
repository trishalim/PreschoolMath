<?php
	include 'dbconnect.php';
	session_start();
	$user =  $_POST['user'];
	$pw = $_POST['pw'];
	$check = mysqli_query($conn,"SELECT * FROM user WHERE username='".$user."'");
	if (mysqli_num_rows($check)==0) {
		echo "Username does not exist.";
	} else {
		$row = mysqli_fetch_assoc($check);
		if($row['type']=='G'){
			if($row['password']==$pw){
				$_SESSION['user'] = $user;
			} else {
				echo "Invalid password.";
			}

		} else {
			echo "This user is not a guardian.";
		}
	}
?>