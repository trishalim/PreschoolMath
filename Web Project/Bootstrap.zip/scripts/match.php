<?php
	include 'dbconnect.php';
	$username = $_POST['username'];
	$pw = $_POST['pw'];
	$userCheck = mysqli_query($conn,"SELECT password FROM user WHERE username='".$username."'");
	$row = mysqli_fetch_array($userCheck);

	if($row['password']==$pw)
		echo "true";
	else echo "false";
?>