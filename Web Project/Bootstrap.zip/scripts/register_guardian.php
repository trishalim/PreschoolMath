 <?php
	include 'dbconnect.php';
	if(!empty($_POST['gusername']) && !empty($_POST['gf_name']) && !empty($_POST['gl_name']) && !empty($_POST['gpassword'])  && !empty($_POST['gcpassword'])) 
	{
	  	$username = $_POST['gusername'];
		$f_name = $_POST['gf_name'];
		$l_name = $_POST['gl_name'];
		$password = $_POST['gpassword'];
		$cpassword = $_POST['gcpassword'];
		if($password != $cpassword)
			echo "Passwords don't match.<br>";
		$userCheck = mysqli_query($conn,"SELECT * FROM user WHERE username='".$username."'");
		if(mysqli_num_rows($userCheck)==0){
			$str_data = "'".$username."',".
				"'".$f_name."',".
				"'".$l_name."',". 
				"'".$password."',". 
				"'G'";
			$query = "INSERT INTO user (username,f_name,l_name,password,type) values (".$str_data.")";
			if(mysqli_query($conn,$query)){
				session_start();
				$_SESSION['user'] = $username;
			}
			
		} else {
			echo "Username already exists. <br>";
		}
	} else {
		echo "All fields are required.<br>";
	}
	
	header('Location: ../index.php');
 ?>