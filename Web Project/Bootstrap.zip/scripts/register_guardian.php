 <?php
	include '../dbconnect.php';
	$username = $_POST['gusername'];
	$f_name = $_POST['gf_name'];
	$l_name = $_POST['gl_name'];
	$password = $_POST['gpassword'];
	
	$userCheck = mysqli_query($conn,"SELECT * FROM user WHERE username='".$username."'");
	if(mysqli_num_rows($userCheck)==0){
		$str_data = "'".$username."',".
			"'".$f_name."',".
			"'".$l_name."',". 
			"'G'";
		$query = "INSERT INTO user (username,f_name,l_name,type) values (".$str_data.")";
		mysqli_query($conn,$query);
		$create_guardian = "INSERT INTO guardian (id,password)
			SELECT
			id,
			'".$password."' AS password
			FROM user where username='".$username."'";
		mysqli_query($conn,$create_guardian);
		echo "Account created.";
		session_start();
		echo $username;
		$_SESSION['user'] = $username;
		header ('Location: ../students.php');
		
	} else {
		echo "Username already exists.";
		header ('Location: ');
	}
 ?>