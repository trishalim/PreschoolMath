<?php 
	include '../dbconnect.php';
	session_start();
	$guardian_username = $_SESSION['user'];
	$student_list = array();
	
	$get_students = "select u.id, u.username, u.f_name, u.l_name from user u, student s 
		where s.user_id=u.id and u.id IN 
		(select student_id from student_list 
		where status = 1 and guardian_id = (select id from user where username='".$guardian_username."'))";
			
	$result = mysqli_query($conn, $get_students);
	if(mysqli_num_rows($result)==0){
		echo "No students enrolled.";
	} else {
		for($i=0; $row =mysqli_fetch_assoc($result); $i++) {
			$student_list[$i] = array();
			$student_list[$i] = $row;
			$game_ave = array();
			$student_username = $row['username'];
			
			//game1 average
			$query_str = "select AVG(score) as avg from score where game_id = 1 and student_id =(select id from user where username='".$row['username']."')";
			$score_list = mysqli_query($conn, $query_str);
			if(mysqli_num_rows($score_list)==0){
				echo "if";
				$game_ave[0] = 0;
			} else {
				$score = mysqli_fetch_row($score_list);
				$game_ave[0] = $score[0];
				$game_ave[0] = round(intval($game_ave[0]));
				if($game_ave[0]==null)
					$game_ave[0] = 0;
				
			}	
			
			//game2 average
			$score_array = array();
			$overall_average = 0;
			for($j=1;$j<=10;$j++){
				$query_str = "select AVG(score) as avg from score where game_id = 2
					and level=".$j."
					and student_id =(select id from user where username='".$row['username']."')";
				$score_list = mysqli_query($conn, $query_str);
				if(mysqli_num_rows($score_list)==0){
					$game_ave[1] = 0;
				} else {
					
					$score_array[$j] = array();
					while($row =mysqli_fetch_assoc($score_list)){
						if($row['avg']==null){
							$row['avg'] = 0;
						} else {
							
						}
							
						$score_array[$j] = $row;
						$overall_average += $row['avg'];
					}
				}
			}
			$game_ave[1] = round($overall_average/10);
			
			//game3 average
			$score_array = array();
			$overall_average = 0;
			for($k=1;$k<=2;$k++){
				$query_str = "select AVG(score) as avg from score where game_id = 3
					and level=".$k."
					and student_id =(select id from user where username='".$student_username."')";
				$score_list = mysqli_query($conn, $query_str);
				if(mysqli_num_rows($score_list)==0){
					$game_ave[2] = 0;
				} else {
					$score_array[$k] = array();
					while($row =mysqli_fetch_assoc($score_list)){
						if($row['avg']==null)
							$row['avg'] = 0;
						$score_array[$k] = $row;
						$overall_average += $row['avg'];
					}
				}
			}
			$game_ave[2] = round($overall_average/2);
			$game_ave[3] = round(($game_ave[0] + $game_ave[1] + $game_ave[2]) / 3);
			$student_list[$i]['game_ave'] = $game_ave;
		}
		echo json_encode($student_list);
	}	
?>