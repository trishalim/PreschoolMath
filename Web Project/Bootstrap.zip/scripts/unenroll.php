<?php
	include '../dbconnect.php';
	session_start();
	$guardian_username = $_SESSION['user'];
	$student_username = $_GET['student_username'];
	echo $student_username;
	$get_stud_id = "select id from user where username='" + $student_username + "'";
	$get_guardian_id = "select id from user where username='" + $guardian_username + "'";
	
	$q = "delete from student_list where student_id=(" + $get_stud_id + ") and guardian_id=(" + $get_guardian_id  + ")";
	$query = mysqli_query($conn, $q);
	if(!$query) 
		die('Invalid query: ' . mysqli_error($query));
	else echo "Ok";
	
?>