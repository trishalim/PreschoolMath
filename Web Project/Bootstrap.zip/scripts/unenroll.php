<?php
	include 'dbconnect.php';
	session_start();
	$guardian_username = $_SESSION['user'];
	$student_username = $_GET['username'];
	echo $student_username;
	$get_stud_id = "select id from user where username='".$student_username."'";
	$get_guardian_id = "select id from user where username='".$guardian_username."'";
	
	$q = "update student_list set status = 0 where student_id=(".$get_stud_id.") and guardian_id=(".$get_guardian_id.")";
	echo $q;
	$query = mysqli_query($conn, $q);
	if(!$query) 
		die('Invalid query: ' . mysqli_error($query));
	else echo "Ok";

	header('Location: ../index.php');
	
?>