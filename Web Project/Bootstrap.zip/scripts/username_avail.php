<?php
	include 'dbconnect.php';
	$username = $_POST['username'];
	$userCheck = mysqli_query($conn,"SELECT * FROM user WHERE username='".$username."'");
	if(mysqli_num_rows($userCheck)==0){
		echo "true";
	}
		
	else echo "false";

?>