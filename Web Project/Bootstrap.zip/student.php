<html>
	<head>
	<link href="css/bootstrap.min.css" rel="stylesheet">
	<script src="js/jquery.js" ></script>
	<script src="js/bootstrap.min.js" ></script>
	<script src="js/student.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	</head>
	<?php include 'header.php'; ?>
	<body>
	<title>Preschool Math | Enrolled Students</title>
	<body>
	
	<?php
		include 'dbconnect.php';
		$student_username = $_GET['user'];
		$query = "select u.username, u.f_name, u.l_name, s.birth_date, s.sex from user u, student s where s.user_id=u.id and u.username='".$student_username."'";
		$get_stud = mysqli_query($conn, $query);
		$row = mysqli_fetch_array($get_stud);
	
	?>
	
	<div class="container">
		<h3>Student</h3>
		<form class="form-horizontal" method="post" action="scripts/edit_student.php?eusername=<?php echo $student_username ?>">
		  <div class="form-group">
			<label for="eusername" class="col-sm-2 control-label">Username</label>
			<div class="col-sm-10 view" style="padding-top:6px;">
				<span><?php echo $student_username ?></span>
			</div>
			<div class="col-sm-10 edit" hidden>
				<input type="text" class="form-control" id="eusername" name="eusername" value="<?php echo $student_username ?>" id="eusername" required="true" disabled>
			</div>
		  </div>
		  <div class="form-group">
			<label for="ef_name" class="col-sm-2 control-label">First Name</label>
			<div class="col-sm-10 view" style="padding-top:6px;">
				<span><?php echo $row['f_name']?></span>
			</div>
			<div class="col-sm-10 edit" hidden>
			  <input type="text" class="form-control" name="ef_name" id="ef_name" value="<?php echo $row['f_name']?>"required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="el_name" class="col-sm-2 control-label">Last Name</label>
			<div class="col-sm-10 view" style="padding-top:6px;">
				<span><?php echo $row['l_name']?></span>
			</div>
			<div class="col-sm-10 edit" hidden>
			  <input type="text" class="form-control" name="el_name" id="el_name"  value="<?php echo $row['l_name']?>" required="true">
			</div>
		  </div>
		  <div class="form-group">
			<label for="esex" class="col-sm-2 control-label">Sex</label>
			<div class="col-sm-10 view" style="padding-top:6px;">
				<span><?php echo ($row['sex']=='M')?"Male":"Female"; ?></span>
			</div>
			<div class="col-sm-10 edit" hidden>
			  <label class="radio-inline">
				  <input type="radio" name="esex" id="esex" value="M" <?php if ($row['sex']=='M') echo "checked=\"checked\"";?> > Male
				</label>
				<label class="radio-inline">
				  <input type="radio" name="esex" id="esex" value="F" <?php if ($row['sex']=='F') echo "checked=\"checked\"";?> > Female
				</label>
			</div>
		  </div>
		  <div class="form-group">
			<label for="ebday" class="col-sm-2 control-label">Birthday</label>
			<div class="col-sm-10 view" style="padding-top:6px;">
				<span><?php echo $row['birth_date']?></span>
			</div>
			<div class="col-sm-10 edit" hidden>
			  <input type="date" class="form-control" name="ebday" id="ebday" value="<?php echo $row['birth_date']?>"  required="true">
			</div>
		  </div>
		  <div class="form-group edit" hidden>
			<label for="password" class="col-sm-2 control-label">Password</label>
			<div class="col-sm-10">
			  <input type="password" class="form-control" name="password" id="epassword" required="true">
			</div>
		  </div>
		  <div class="modal-footer">
			<button id="rCancelBtn" type="button" class="btn btn-default edit" data-dismiss="modal" style="display:none;">Cancel</button>
			<a id="cancelBtn" href="students.php" type="button" class="btn btn-default view" data-dismiss="modal">Cancel</a>
			<a type="button" id="unenrollBtn" class="btn btn-warning edit" href="scripts/unenroll.php?student_username=<?php echo $student_username; ?>"  style="display:none;">Unenroll</a>
			<button type="submit" id="saveStudentBtn" class="btn btn-primary edit" style="display:none;">Save changes</button>
			<button type="button" id="editBtn" class="btn btn-primary view">Edit</button>
		  </div>
		</form>
		
	</div>
	</body>
	</body>
</html>