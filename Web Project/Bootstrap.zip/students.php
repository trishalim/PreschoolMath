<html>


<head>
	<script src="js/jquery.js" ></script>
	<script src="js/Chart.js" ></script>
	<script src="js/index.js" ></script>
	<link href="css/index.css" rel="stylesheet">
	<script src="datatables/media/js/datatables.js" ></script>
	<link href="css/bootstrap.min.css" rel="stylesheet" >
	
	<script src="js/bootstrap.min.js" integrity="sha256-KXn5puMvxCw+dAYznun+drMdG1IFl3agK0p/pqT9KAo= sha512-2e8qq0ETcfWRI4HJBzQiA3UoyFk6tbNyG+qSaIBZLyW9Xf3sWZHN/lxe9fTh1U45DpPf07yj94KsUHHWe4Yk1A==" crossorigin="anonymous"></script>
	<script src="js/students.js" ></script>
	<script src="js/datatables.bootstrap.js" ></script>
	<link href="css/students.css" rel="stylesheet">
	<link href="css/index.css" rel="stylesheet">
	<link href="css/datatables.bootstrap.css" rel="stylesheet">
</head>
<?php include 'header.php'; ?>
<title>Preschool Math | Enrolled Students</title>
<body>
	<div class="container">
		<br>
		<div class="row">
			<div class="col-xs-3">
				<h4>Enrolled Students</h4>
			</div>
			<div class="col-xs-4">
				<div class="input-group">
					<input id="enroll_user" type="text" class="form-control" name="student_username" placeholder="Enter username">
					<span class="input-group-btn">
						<button id="enrollBtn" class="btn btn-primary">Enroll</button>
					</span>
				</div>
			</div>
			<div class="col-xs-2" style="padding:0px;" >
				<a id="createStudentBtn" href="create_student.php" class="btn btn-primary">New Student</a>
			</div>
			<div class="col-xs-3" style="padding-left:0px;" >
				<input type="text" id="search_student" class="form-control" placeholder="Search...">
			</div>
		</div>
		
		<table id="students_list" class="table table-striped table-bordered" cellspacing="0" width="100%"> 
			<thead>
				<tr>
					<th rowspan="2">Username</th>
					<th colspan="4"><center>Average Scores</center></th>
				</tr>
				<tr>
					<th>Shape Recognition</th>
					<th>Counting Numbers</th>
					<th>Addition & Subtraction</th>
					<th>Overall</th>
				</tr>
			</thead>
			<tbody>
			</tbody>
		</table>
	</div>
</body>

<div class="modal fade" id="editStudent" tabindex="-1" role="dialog" aria-labelledby="editStudent">
	<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="myModalLabel">Edit Student Information</h4>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" method="post" action="edit_student.php">
					<div class="form-group">
						<label for="eusername" class="col-sm-2 control-label">Username</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="eusername" id="eusername" required="true">
						</div>
					</div>
					<div class="form-group">
						<label for="ef_name" class="col-sm-2 control-label">First Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="ef_name" id="ef_name" required="true">
						</div>
					</div>
					<div class="form-group">
						<label for="el_name" class="col-sm-2 control-label">Last Name</label>
						<div class="col-sm-10">
							<input type="text" class="form-control" name="el_name" id="el_name" required="true">
						</div>
					</div>
					<div class="form-group">
						<label for="esex" class="col-sm-2 control-label">Sex</label>
						<div class="col-sm-10">
							<label class="radio-inline">
								<input type="radio" name="esex" id="male" value="M" checked="checked"> Male
							</label>
							<label class="radio-inline">
								<input type="radio" name="esex" id="female" value="F"> Female
							</label>
						</div>
					</div>
					<div class="form-group">
						<label for="ebday" class="col-sm-2 control-label">Birthday</label>
						<div class="col-sm-10">
							<input type="date" class="form-control" name="ebday" id="bday" required="true">
						</div>
					</div>
					<div class="form-group">
						<label for="password" class="col-sm-2 control-label">Password</label>
						<div class="col-sm-10">
							<input type="password" class="form-control" name="password" id="password" required="true">
						</div>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-warning">Unenroll</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div>
	</div>
</div>
<div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" id="enrollModal" aria-labelledby="enrollModal">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
	      <div class="modal-body" >
	      	<h4 class="text-center" id="enrollMsg"></h4>
	      </div>
			<div class="modal-footer">
				<button type="button" class="btn btn-primary" data-dismiss="modal">OK</button>
			</div>
		</div>

	</div>
</div>
</html>